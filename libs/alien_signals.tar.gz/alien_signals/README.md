## @pyscript/lib/alien_signals

This is a pure Python port of the lightest and fastest [alien_signals](https://github.com/stackblitz/alien-signals) library, usable to create reactive logic within a variety of use cases.
